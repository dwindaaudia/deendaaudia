﻿namespace appdevTHW2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_word1 = new System.Windows.Forms.Label();
            this.lb_word2 = new System.Windows.Forms.Label();
            this.lb_word4 = new System.Windows.Forms.Label();
            this.lb_word3 = new System.Windows.Forms.Label();
            this.lb_word5 = new System.Windows.Forms.Label();
            this.tb_word1 = new System.Windows.Forms.TextBox();
            this.tb_word2 = new System.Windows.Forms.TextBox();
            this.tb_word3 = new System.Windows.Forms.TextBox();
            this.tb_word4 = new System.Windows.Forms.TextBox();
            this.tb_word5 = new System.Windows.Forms.TextBox();
            this.bt_play = new System.Windows.Forms.Button();
            this.pnl_word = new System.Windows.Forms.Panel();
            this.bt_q = new System.Windows.Forms.Button();
            this.bt_w = new System.Windows.Forms.Button();
            this.bt_e = new System.Windows.Forms.Button();
            this.bt_r = new System.Windows.Forms.Button();
            this.bt_t = new System.Windows.Forms.Button();
            this.bt_y = new System.Windows.Forms.Button();
            this.bt_u = new System.Windows.Forms.Button();
            this.bt_i = new System.Windows.Forms.Button();
            this.bt_o = new System.Windows.Forms.Button();
            this.bt_p = new System.Windows.Forms.Button();
            this.bt_l = new System.Windows.Forms.Button();
            this.bt_k = new System.Windows.Forms.Button();
            this.bt_j = new System.Windows.Forms.Button();
            this.bt_h = new System.Windows.Forms.Button();
            this.bt_g = new System.Windows.Forms.Button();
            this.bt_f = new System.Windows.Forms.Button();
            this.bt_d = new System.Windows.Forms.Button();
            this.bt_s = new System.Windows.Forms.Button();
            this.bt_a = new System.Windows.Forms.Button();
            this.bt_m = new System.Windows.Forms.Button();
            this.bt_n = new System.Windows.Forms.Button();
            this.bt_b = new System.Windows.Forms.Button();
            this.bt_v = new System.Windows.Forms.Button();
            this.bt_c = new System.Windows.Forms.Button();
            this.bt_x = new System.Windows.Forms.Button();
            this.bt_z = new System.Windows.Forms.Button();
            this.pnl_play = new System.Windows.Forms.Panel();
            this.tebak5 = new System.Windows.Forms.Label();
            this.tebak4 = new System.Windows.Forms.Label();
            this.tebak3 = new System.Windows.Forms.Label();
            this.tebak2 = new System.Windows.Forms.Label();
            this.tebak1 = new System.Windows.Forms.Label();
            this.pnl_word.SuspendLayout();
            this.pnl_play.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_word1
            // 
            this.lb_word1.AutoSize = true;
            this.lb_word1.Location = new System.Drawing.Point(37, 33);
            this.lb_word1.Name = "lb_word1";
            this.lb_word1.Size = new System.Drawing.Size(72, 20);
            this.lb_word1.TabIndex = 0;
            this.lb_word1.Text = "Word 1 : ";
            // 
            // lb_word2
            // 
            this.lb_word2.AutoSize = true;
            this.lb_word2.Location = new System.Drawing.Point(37, 71);
            this.lb_word2.Name = "lb_word2";
            this.lb_word2.Size = new System.Drawing.Size(72, 20);
            this.lb_word2.TabIndex = 1;
            this.lb_word2.Text = "Word 2 : ";
            // 
            // lb_word4
            // 
            this.lb_word4.AutoSize = true;
            this.lb_word4.Location = new System.Drawing.Point(37, 147);
            this.lb_word4.Name = "lb_word4";
            this.lb_word4.Size = new System.Drawing.Size(72, 20);
            this.lb_word4.TabIndex = 3;
            this.lb_word4.Text = "Word 4 : ";
            // 
            // lb_word3
            // 
            this.lb_word3.AutoSize = true;
            this.lb_word3.Location = new System.Drawing.Point(37, 110);
            this.lb_word3.Name = "lb_word3";
            this.lb_word3.Size = new System.Drawing.Size(72, 20);
            this.lb_word3.TabIndex = 2;
            this.lb_word3.Text = "Word 3 : ";
            // 
            // lb_word5
            // 
            this.lb_word5.AutoSize = true;
            this.lb_word5.Location = new System.Drawing.Point(37, 183);
            this.lb_word5.Name = "lb_word5";
            this.lb_word5.Size = new System.Drawing.Size(72, 20);
            this.lb_word5.TabIndex = 4;
            this.lb_word5.Text = "Word 5 : ";
            // 
            // tb_word1
            // 
            this.tb_word1.Location = new System.Drawing.Point(136, 27);
            this.tb_word1.Name = "tb_word1";
            this.tb_word1.Size = new System.Drawing.Size(171, 26);
            this.tb_word1.TabIndex = 5;
            this.tb_word1.TextChanged += new System.EventHandler(this.tb_word1_TextChanged);
            // 
            // tb_word2
            // 
            this.tb_word2.Location = new System.Drawing.Point(136, 65);
            this.tb_word2.Name = "tb_word2";
            this.tb_word2.Size = new System.Drawing.Size(171, 26);
            this.tb_word2.TabIndex = 6;
            // 
            // tb_word3
            // 
            this.tb_word3.Location = new System.Drawing.Point(136, 104);
            this.tb_word3.Name = "tb_word3";
            this.tb_word3.Size = new System.Drawing.Size(171, 26);
            this.tb_word3.TabIndex = 7;
            // 
            // tb_word4
            // 
            this.tb_word4.Location = new System.Drawing.Point(136, 141);
            this.tb_word4.Name = "tb_word4";
            this.tb_word4.Size = new System.Drawing.Size(171, 26);
            this.tb_word4.TabIndex = 8;
            // 
            // tb_word5
            // 
            this.tb_word5.Location = new System.Drawing.Point(136, 177);
            this.tb_word5.Name = "tb_word5";
            this.tb_word5.Size = new System.Drawing.Size(171, 26);
            this.tb_word5.TabIndex = 9;
            // 
            // bt_play
            // 
            this.bt_play.Location = new System.Drawing.Point(136, 231);
            this.bt_play.Name = "bt_play";
            this.bt_play.Size = new System.Drawing.Size(99, 35);
            this.bt_play.TabIndex = 10;
            this.bt_play.Text = "Play!";
            this.bt_play.UseVisualStyleBackColor = true;
            this.bt_play.Click += new System.EventHandler(this.bt_play_Click);
            // 
            // pnl_word
            // 
            this.pnl_word.Controls.Add(this.bt_play);
            this.pnl_word.Controls.Add(this.tb_word5);
            this.pnl_word.Controls.Add(this.tb_word4);
            this.pnl_word.Controls.Add(this.tb_word3);
            this.pnl_word.Controls.Add(this.tb_word2);
            this.pnl_word.Controls.Add(this.tb_word1);
            this.pnl_word.Controls.Add(this.lb_word5);
            this.pnl_word.Controls.Add(this.lb_word4);
            this.pnl_word.Controls.Add(this.lb_word3);
            this.pnl_word.Controls.Add(this.lb_word2);
            this.pnl_word.Controls.Add(this.lb_word1);
            this.pnl_word.Location = new System.Drawing.Point(35, 12);
            this.pnl_word.Name = "pnl_word";
            this.pnl_word.Size = new System.Drawing.Size(372, 282);
            this.pnl_word.TabIndex = 11;
            // 
            // bt_q
            // 
            this.bt_q.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_q.Location = new System.Drawing.Point(37, 102);
            this.bt_q.Name = "bt_q";
            this.bt_q.Size = new System.Drawing.Size(75, 70);
            this.bt_q.TabIndex = 12;
            this.bt_q.Text = "Q";
            this.bt_q.UseVisualStyleBackColor = true;
            this.bt_q.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_w
            // 
            this.bt_w.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_w.Location = new System.Drawing.Point(118, 102);
            this.bt_w.Name = "bt_w";
            this.bt_w.Size = new System.Drawing.Size(75, 70);
            this.bt_w.TabIndex = 13;
            this.bt_w.Text = "W";
            this.bt_w.UseVisualStyleBackColor = true;
            this.bt_w.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_e
            // 
            this.bt_e.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_e.Location = new System.Drawing.Point(199, 102);
            this.bt_e.Name = "bt_e";
            this.bt_e.Size = new System.Drawing.Size(75, 70);
            this.bt_e.TabIndex = 14;
            this.bt_e.Text = "E";
            this.bt_e.UseVisualStyleBackColor = true;
            this.bt_e.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_r
            // 
            this.bt_r.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_r.Location = new System.Drawing.Point(280, 102);
            this.bt_r.Name = "bt_r";
            this.bt_r.Size = new System.Drawing.Size(75, 70);
            this.bt_r.TabIndex = 15;
            this.bt_r.Text = "R";
            this.bt_r.UseVisualStyleBackColor = true;
            this.bt_r.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_t
            // 
            this.bt_t.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_t.Location = new System.Drawing.Point(361, 102);
            this.bt_t.Name = "bt_t";
            this.bt_t.Size = new System.Drawing.Size(75, 70);
            this.bt_t.TabIndex = 16;
            this.bt_t.Text = "T";
            this.bt_t.UseVisualStyleBackColor = true;
            this.bt_t.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_y
            // 
            this.bt_y.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_y.Location = new System.Drawing.Point(442, 102);
            this.bt_y.Name = "bt_y";
            this.bt_y.Size = new System.Drawing.Size(75, 70);
            this.bt_y.TabIndex = 17;
            this.bt_y.Text = "Y";
            this.bt_y.UseVisualStyleBackColor = true;
            this.bt_y.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_u
            // 
            this.bt_u.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_u.Location = new System.Drawing.Point(523, 102);
            this.bt_u.Name = "bt_u";
            this.bt_u.Size = new System.Drawing.Size(75, 70);
            this.bt_u.TabIndex = 18;
            this.bt_u.Text = "U";
            this.bt_u.UseVisualStyleBackColor = true;
            this.bt_u.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_i
            // 
            this.bt_i.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_i.Location = new System.Drawing.Point(604, 102);
            this.bt_i.Name = "bt_i";
            this.bt_i.Size = new System.Drawing.Size(75, 70);
            this.bt_i.TabIndex = 19;
            this.bt_i.Text = "I";
            this.bt_i.UseVisualStyleBackColor = true;
            this.bt_i.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_o
            // 
            this.bt_o.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_o.Location = new System.Drawing.Point(685, 102);
            this.bt_o.Name = "bt_o";
            this.bt_o.Size = new System.Drawing.Size(75, 70);
            this.bt_o.TabIndex = 20;
            this.bt_o.Text = "O";
            this.bt_o.UseVisualStyleBackColor = true;
            this.bt_o.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_p
            // 
            this.bt_p.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_p.Location = new System.Drawing.Point(766, 102);
            this.bt_p.Name = "bt_p";
            this.bt_p.Size = new System.Drawing.Size(75, 70);
            this.bt_p.TabIndex = 21;
            this.bt_p.Text = "P";
            this.bt_p.UseVisualStyleBackColor = true;
            this.bt_p.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_l
            // 
            this.bt_l.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_l.Location = new System.Drawing.Point(726, 178);
            this.bt_l.Name = "bt_l";
            this.bt_l.Size = new System.Drawing.Size(75, 70);
            this.bt_l.TabIndex = 30;
            this.bt_l.Text = "L";
            this.bt_l.UseVisualStyleBackColor = true;
            this.bt_l.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_k
            // 
            this.bt_k.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_k.Location = new System.Drawing.Point(645, 178);
            this.bt_k.Name = "bt_k";
            this.bt_k.Size = new System.Drawing.Size(75, 70);
            this.bt_k.TabIndex = 29;
            this.bt_k.Text = "K";
            this.bt_k.UseVisualStyleBackColor = true;
            this.bt_k.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_j
            // 
            this.bt_j.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_j.Location = new System.Drawing.Point(564, 178);
            this.bt_j.Name = "bt_j";
            this.bt_j.Size = new System.Drawing.Size(75, 70);
            this.bt_j.TabIndex = 28;
            this.bt_j.Text = "J";
            this.bt_j.UseVisualStyleBackColor = true;
            this.bt_j.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_h
            // 
            this.bt_h.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_h.Location = new System.Drawing.Point(483, 178);
            this.bt_h.Name = "bt_h";
            this.bt_h.Size = new System.Drawing.Size(75, 70);
            this.bt_h.TabIndex = 27;
            this.bt_h.Text = "H";
            this.bt_h.UseVisualStyleBackColor = true;
            this.bt_h.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_g
            // 
            this.bt_g.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_g.Location = new System.Drawing.Point(402, 178);
            this.bt_g.Name = "bt_g";
            this.bt_g.Size = new System.Drawing.Size(75, 70);
            this.bt_g.TabIndex = 26;
            this.bt_g.Text = "G";
            this.bt_g.UseVisualStyleBackColor = true;
            this.bt_g.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_f
            // 
            this.bt_f.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_f.Location = new System.Drawing.Point(321, 178);
            this.bt_f.Name = "bt_f";
            this.bt_f.Size = new System.Drawing.Size(75, 70);
            this.bt_f.TabIndex = 25;
            this.bt_f.Text = "F";
            this.bt_f.UseVisualStyleBackColor = true;
            this.bt_f.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_d
            // 
            this.bt_d.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_d.Location = new System.Drawing.Point(240, 178);
            this.bt_d.Name = "bt_d";
            this.bt_d.Size = new System.Drawing.Size(75, 70);
            this.bt_d.TabIndex = 24;
            this.bt_d.Text = "D";
            this.bt_d.UseVisualStyleBackColor = true;
            this.bt_d.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_s
            // 
            this.bt_s.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_s.Location = new System.Drawing.Point(159, 178);
            this.bt_s.Name = "bt_s";
            this.bt_s.Size = new System.Drawing.Size(75, 70);
            this.bt_s.TabIndex = 23;
            this.bt_s.Text = "S";
            this.bt_s.UseVisualStyleBackColor = true;
            this.bt_s.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_a
            // 
            this.bt_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_a.Location = new System.Drawing.Point(78, 178);
            this.bt_a.Name = "bt_a";
            this.bt_a.Size = new System.Drawing.Size(75, 70);
            this.bt_a.TabIndex = 22;
            this.bt_a.Text = "A";
            this.bt_a.UseVisualStyleBackColor = true;
            this.bt_a.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_m
            // 
            this.bt_m.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_m.Location = new System.Drawing.Point(645, 254);
            this.bt_m.Name = "bt_m";
            this.bt_m.Size = new System.Drawing.Size(75, 70);
            this.bt_m.TabIndex = 37;
            this.bt_m.Text = "M";
            this.bt_m.UseVisualStyleBackColor = true;
            this.bt_m.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_n
            // 
            this.bt_n.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_n.Location = new System.Drawing.Point(564, 254);
            this.bt_n.Name = "bt_n";
            this.bt_n.Size = new System.Drawing.Size(75, 70);
            this.bt_n.TabIndex = 36;
            this.bt_n.Text = "N";
            this.bt_n.UseVisualStyleBackColor = true;
            this.bt_n.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_b
            // 
            this.bt_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_b.Location = new System.Drawing.Point(483, 254);
            this.bt_b.Name = "bt_b";
            this.bt_b.Size = new System.Drawing.Size(75, 70);
            this.bt_b.TabIndex = 35;
            this.bt_b.Text = "B";
            this.bt_b.UseVisualStyleBackColor = true;
            this.bt_b.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_v
            // 
            this.bt_v.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_v.Location = new System.Drawing.Point(402, 254);
            this.bt_v.Name = "bt_v";
            this.bt_v.Size = new System.Drawing.Size(75, 70);
            this.bt_v.TabIndex = 34;
            this.bt_v.Text = "V";
            this.bt_v.UseVisualStyleBackColor = true;
            this.bt_v.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_c
            // 
            this.bt_c.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_c.Location = new System.Drawing.Point(321, 254);
            this.bt_c.Name = "bt_c";
            this.bt_c.Size = new System.Drawing.Size(75, 70);
            this.bt_c.TabIndex = 33;
            this.bt_c.Text = "C";
            this.bt_c.UseVisualStyleBackColor = true;
            this.bt_c.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_x
            // 
            this.bt_x.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_x.Location = new System.Drawing.Point(240, 254);
            this.bt_x.Name = "bt_x";
            this.bt_x.Size = new System.Drawing.Size(75, 70);
            this.bt_x.TabIndex = 32;
            this.bt_x.Text = "X";
            this.bt_x.UseVisualStyleBackColor = true;
            this.bt_x.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // bt_z
            // 
            this.bt_z.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_z.Location = new System.Drawing.Point(159, 254);
            this.bt_z.Name = "bt_z";
            this.bt_z.Size = new System.Drawing.Size(75, 70);
            this.bt_z.TabIndex = 31;
            this.bt_z.Text = "Z";
            this.bt_z.UseVisualStyleBackColor = true;
            this.bt_z.Click += new System.EventHandler(this.bt_m_Click);
            // 
            // pnl_play
            // 
            this.pnl_play.Controls.Add(this.tebak5);
            this.pnl_play.Controls.Add(this.tebak4);
            this.pnl_play.Controls.Add(this.tebak3);
            this.pnl_play.Controls.Add(this.tebak2);
            this.pnl_play.Controls.Add(this.tebak1);
            this.pnl_play.Controls.Add(this.bt_m);
            this.pnl_play.Controls.Add(this.bt_n);
            this.pnl_play.Controls.Add(this.bt_b);
            this.pnl_play.Controls.Add(this.bt_v);
            this.pnl_play.Controls.Add(this.bt_c);
            this.pnl_play.Controls.Add(this.bt_x);
            this.pnl_play.Controls.Add(this.bt_z);
            this.pnl_play.Controls.Add(this.bt_l);
            this.pnl_play.Controls.Add(this.bt_k);
            this.pnl_play.Controls.Add(this.bt_j);
            this.pnl_play.Controls.Add(this.bt_h);
            this.pnl_play.Controls.Add(this.bt_g);
            this.pnl_play.Controls.Add(this.bt_f);
            this.pnl_play.Controls.Add(this.bt_d);
            this.pnl_play.Controls.Add(this.bt_s);
            this.pnl_play.Controls.Add(this.bt_a);
            this.pnl_play.Controls.Add(this.bt_p);
            this.pnl_play.Controls.Add(this.bt_o);
            this.pnl_play.Controls.Add(this.bt_i);
            this.pnl_play.Controls.Add(this.bt_u);
            this.pnl_play.Controls.Add(this.bt_y);
            this.pnl_play.Controls.Add(this.bt_t);
            this.pnl_play.Controls.Add(this.bt_r);
            this.pnl_play.Controls.Add(this.bt_e);
            this.pnl_play.Controls.Add(this.bt_w);
            this.pnl_play.Controls.Add(this.bt_q);
            this.pnl_play.Location = new System.Drawing.Point(35, 300);
            this.pnl_play.Name = "pnl_play";
            this.pnl_play.Size = new System.Drawing.Size(881, 383);
            this.pnl_play.TabIndex = 38;
            this.pnl_play.Visible = false;
            // 
            // tebak5
            // 
            this.tebak5.AutoSize = true;
            this.tebak5.Font = new System.Drawing.Font("MS Reference Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tebak5.Location = new System.Drawing.Point(469, 24);
            this.tebak5.Name = "tebak5";
            this.tebak5.Size = new System.Drawing.Size(53, 55);
            this.tebak5.TabIndex = 43;
            this.tebak5.Text = "_";
            // 
            // tebak4
            // 
            this.tebak4.AutoSize = true;
            this.tebak4.Font = new System.Drawing.Font("MS Reference Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tebak4.Location = new System.Drawing.Point(410, 24);
            this.tebak4.Name = "tebak4";
            this.tebak4.Size = new System.Drawing.Size(53, 55);
            this.tebak4.TabIndex = 42;
            this.tebak4.Text = "_";
            // 
            // tebak3
            // 
            this.tebak3.AutoSize = true;
            this.tebak3.Font = new System.Drawing.Font("MS Reference Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tebak3.Location = new System.Drawing.Point(351, 24);
            this.tebak3.Name = "tebak3";
            this.tebak3.Size = new System.Drawing.Size(53, 55);
            this.tebak3.TabIndex = 41;
            this.tebak3.Text = "_";
            // 
            // tebak2
            // 
            this.tebak2.AutoSize = true;
            this.tebak2.Font = new System.Drawing.Font("MS Reference Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tebak2.Location = new System.Drawing.Point(290, 24);
            this.tebak2.Name = "tebak2";
            this.tebak2.Size = new System.Drawing.Size(53, 55);
            this.tebak2.TabIndex = 40;
            this.tebak2.Text = "_";
            // 
            // tebak1
            // 
            this.tebak1.AutoSize = true;
            this.tebak1.Font = new System.Drawing.Font("MS Reference Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tebak1.Location = new System.Drawing.Point(231, 24);
            this.tebak1.Name = "tebak1";
            this.tebak1.Size = new System.Drawing.Size(53, 55);
            this.tebak1.TabIndex = 39;
            this.tebak1.Text = "_";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1033, 768);
            this.Controls.Add(this.pnl_play);
            this.Controls.Add(this.pnl_word);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_word.ResumeLayout(false);
            this.pnl_word.PerformLayout();
            this.pnl_play.ResumeLayout(false);
            this.pnl_play.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_word1;
        private System.Windows.Forms.Label lb_word2;
        private System.Windows.Forms.Label lb_word4;
        private System.Windows.Forms.Label lb_word3;
        private System.Windows.Forms.Label lb_word5;
        private System.Windows.Forms.TextBox tb_word1;
        private System.Windows.Forms.TextBox tb_word2;
        private System.Windows.Forms.TextBox tb_word3;
        private System.Windows.Forms.TextBox tb_word4;
        private System.Windows.Forms.TextBox tb_word5;
        private System.Windows.Forms.Button bt_play;
        private System.Windows.Forms.Panel pnl_word;
        private System.Windows.Forms.Button bt_q;
        private System.Windows.Forms.Button bt_w;
        private System.Windows.Forms.Button bt_e;
        private System.Windows.Forms.Button bt_r;
        private System.Windows.Forms.Button bt_t;
        private System.Windows.Forms.Button bt_y;
        private System.Windows.Forms.Button bt_u;
        private System.Windows.Forms.Button bt_i;
        private System.Windows.Forms.Button bt_o;
        private System.Windows.Forms.Button bt_p;
        private System.Windows.Forms.Button bt_l;
        private System.Windows.Forms.Button bt_k;
        private System.Windows.Forms.Button bt_j;
        private System.Windows.Forms.Button bt_h;
        private System.Windows.Forms.Button bt_g;
        private System.Windows.Forms.Button bt_f;
        private System.Windows.Forms.Button bt_d;
        private System.Windows.Forms.Button bt_s;
        private System.Windows.Forms.Button bt_a;
        private System.Windows.Forms.Button bt_m;
        private System.Windows.Forms.Button bt_n;
        private System.Windows.Forms.Button bt_b;
        private System.Windows.Forms.Button bt_v;
        private System.Windows.Forms.Button bt_c;
        private System.Windows.Forms.Button bt_x;
        private System.Windows.Forms.Button bt_z;
        private System.Windows.Forms.Panel pnl_play;
        private System.Windows.Forms.Label tebak1;
        private System.Windows.Forms.Label tebak5;
        private System.Windows.Forms.Label tebak4;
        private System.Windows.Forms.Label tebak3;
        private System.Windows.Forms.Label tebak2;
    }
}

