﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appdevTHW2
{
    public partial class Form1 : Form
    {
        List<Label> tebakLabel = new List<Label>();
        string kataRandom = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void tb_word1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bt_play_Click(object sender, EventArgs e)
        {
            bool error = true;
            pnl_play.Visible = true;
            List<string> inputWord = new List<string>();
            inputWord.Add(tb_word1.Text.ToUpper());
            inputWord.Add(tb_word2.Text.ToUpper());
            inputWord.Add(tb_word3.Text.ToUpper());
            inputWord.Add(tb_word4.Text.ToUpper());
            inputWord.Add(tb_word5.Text.ToUpper());
            if (tb_word1.Text.Length < 5 || tb_word2.Text.Length < 5 || tb_word3.Text.Length < 5 || tb_word4.Text.Length < 5 || tb_word5.Text.Length < 5 || tb_word1.Text.Length > 5 || tb_word2.Text.Length > 5 || tb_word3.Text.Length > 5 || tb_word4.Text.Length > 5 || tb_word5.Text.Length > 5 || tb_word1.Text == tb_word2.Text || tb_word1.Text == tb_word3.Text || tb_word1.Text == tb_word4.Text || tb_word1.Text == tb_word5.Text || tb_word2.Text == tb_word3.Text || tb_word2.Text == tb_word4.Text || tb_word2.Text== tb_word5.Text || tb_word3.Text == tb_word4.Text || tb_word3.Text == tb_word5.Text || tb_word4.Text == tb_word5.Text)
            {
                MessageBox.Show("Masih ada error");
                pnl_play.Visible = false;            
            }
            else
            {
                MessageBox.Show("Ayooo!");
                pnl_word.Visible = false;                
            }
            Random rnd = new Random();
            int randomsay = rnd.Next(0, 5);
            kataRandom = inputWord[randomsay];
            tebakLabel.AddRange(new Label[] { tebak1, tebak2, tebak3, tebak4, tebak5 });
        }     
        int angka = 0;
        private void bt_m_Click(object sender, EventArgs e)
        {
            Button m = sender as Button;
            string h = m.Text.ToString();
            char a = Convert.ToChar(h);
            for (int i = 0; i < kataRandom.Length; i++)
            {
                if (kataRandom[i] == a)
                {
                    angka = i;
                    if (angka == 0)
                    {
                        tebak1.Text = a.ToString();
                    }
                    if (angka == 1)
                    {
                        tebak2.Text = a.ToString();
                    }
                    if (angka == 2)
                    {
                        tebak3.Text = a.ToString();
                    }
                    if (angka == 3)
                    {
                        tebak4.Text = a.ToString();
                    }
                    if (angka == 4)
                    {
                        tebak5.Text = a.ToString();
                    }
                    if (tebak1.Text != "_" && tebak2.Text != "_" && tebak3.Text != "_" && tebak4.Text != "_" && tebak5.Text != "_" )
                    {
                        MessageBox.Show("Yeeeyy menang !!");
                    }
                }
            }            
        }
    }
}
